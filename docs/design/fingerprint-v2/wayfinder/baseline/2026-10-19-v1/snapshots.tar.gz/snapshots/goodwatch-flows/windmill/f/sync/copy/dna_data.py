from collections import defaultdict
from datetime import datetime, timedelta
from typing import Optional

from mongoengine import get_db
from pydantic import BaseModel

from f.db.cratedb import CrateConnector
from f.db.mongodb import (
    init_mongodb,
    close_mongodb,
    build_query_selector_for_object_ids,
)
from f.sync.copy import sync_state
from f.sync.copy.deleted_titles import flagged_among
from f.sync.models.crate_models import (
    Movie,
    Show,
)
from f.sync.models.crate_schemas import SCHEMAS

BATCH_SIZE = 5000
SUB_BATCH_SIZE = 50000
# Window of a recent copy restricted by a selector. A scheduled run reads from its last
# successful run instead (f/sync/copy/sync_state).
HOURS_TO_FETCH = 24*2
SYNC_JOB = "dna_data"


# ===== Helper Functions =====

def to_timestamp(dt_input: str) -> Optional[float]:
    """Convert datetime to Unix timestamp."""
    if isinstance(dt_input, datetime):
        return dt_input.timestamp()
    if isinstance(dt_input, str):
        try:
            dt = datetime.strptime(dt_input, '%Y-%m-%dT%H:%M:%S.%fZ')
            return dt.timestamp()
        except Exception:
            pass
        try:
            dt = datetime.strptime(dt_input, '%Y-%m-%d %H:%M:%S.%f')
            return dt.timestamp()
        except Exception:
            pass
        try:
            dt = datetime.strptime(dt_input, '%Y-%m-%d %H:%M:%S UTC')
            return dt.timestamp()
        except Exception:
            pass
        try:
            dt = datetime.strptime(dt_input, '%Y-%m-%d')
            return dt.timestamp()
        except Exception:
            pass

        raise Exception(f"cannot convert datetime to timestamp: {dt_input}")
        

def fetch_documents_in_batch(tmdb_ids, collection):
    projection = {
        "tmdb_id": 1,
    }
    return {
        doc["tmdb_id"]: doc for doc in collection.find({"tmdb_id": {"$in": tmdb_ids}}, projection)
    }


def fetch_all_documents_in_batch(tmdb_ids, collection):
    results = defaultdict(list)
    for doc in collection.find({"tmdb_id": {"$in": tmdb_ids}}):
        if doc.get('created_at') and doc.get('updated_at'):
            results[doc["tmdb_id"]].append(doc)
    return dict(results)


def upsert_in_batches(connector: CrateConnector, table: str, records: list[BaseModel]):
    """Process and insert entities and return upsert results."""
    total_result = {"records_received": 0, "rows_upserted": 0}
    
    if records:
        print(f"    Upserting {len(records)} of type {table}")
        for i in range(0, len(records), SUB_BATCH_SIZE):
            batch = records[i:i + SUB_BATCH_SIZE]
            if batch:
                result = connector.upsert_many(
                    table=table,
                    records=batch,
                    conflict_columns=SCHEMAS[table]["primary_key"],
                    silent=True,
                )
                total_result["records_received"] += result["records_received"]
                total_result["rows_upserted"] += result["rows_upserted"]
    
    return total_result

def copy_media(
    connector: CrateConnector, 
    query_selector: dict = {},
    media_type: str = "movie",
    *, recent_only: bool = True, since: Optional[datetime] = None,
):
    """Copy the title analyses that match the selector to CrateDB.

    A recent copy takes the analyses changed since `since`, by default in the last
    HOURS_TO_FETCH hours. With recent_only=False it takes every analysis.

    An analysis is left out while its title has no details document or is flagged as
    deleted on TMDB. Nothing here retries it: the catch-up of a scheduled run copies it
    once the title has a Crate row and can be copied.
    """
    is_movie = media_type == "movie"

    mongo_db = get_db()
    mongo_details = mongo_db.tmdb_movie_details if is_movie else mongo_db.tmdb_tv_details
    mongo_dna = mongo_db.dna_movie if is_movie else mongo_db.dna_tv
    media_table_name = 'movie' if is_movie else 'show'
    MediaClass = Movie if is_movie else Show

    updated_at_filter = {"updated_at": {"$gte": since or datetime.utcnow() - timedelta(hours=HOURS_TO_FETCH)}}
    if not recent_only:
        updated_at_filter = {}
    total_entry_count = mongo_dna.count_documents(query_selector | updated_at_filter)
    print(f"Total {media_type} DNA entries: {total_entry_count}")

    start = 0
    entity_counts = defaultdict(lambda: {"records_received": 0, "rows_upserted": 0})
    selected = 0
    skipped_without_details = 0
    skipped_flagged = 0

    while True:
        media_documents = []
        entity_batches = defaultdict(list)

        dna_data_batch = list(
            #mongo_dna.find({"tmdb_id": {"$lt": 1000}} | updated_at_filter, projection)
            mongo_dna.find(query_selector | updated_at_filter)
                .sort("tmdb_id", 1)
                .skip(start)
                .limit(BATCH_SIZE)
        )
        if not dna_data_batch:
            break

        # Insert batch of media
        print(f"\nBatch from {start} to {start + len(dna_data_batch)} {media_type} DNA entries")

        selected += len(dna_data_batch)
        tmdb_ids = [doc["tmdb_id"] for doc in dna_data_batch]
        # Do not re-insert derived rows for titles deleted on TMDB.
        flagged_ids = flagged_among(mongo_details, tmdb_ids)
        tmdb_details_by_id = fetch_documents_in_batch(
            tmdb_ids, 
            mongo_details,
        )

        for dna_data in dna_data_batch:
            tmdb_id = dna_data["tmdb_id"]
            tmdb_details = tmdb_details_by_id.get(tmdb_id)

            if not tmdb_details or tmdb_id in flagged_ids:
                if tmdb_details:
                    skipped_flagged += 1
                else:
                    skipped_without_details += 1
                continue
     
            has_dna = "dna" in dna_data and "vector_fingerprint" in dna_data
            essence_tags = dna_data["dna"].get("essence_tags", []) if has_dna else None
            essence_text = dna_data["dna"]["essence_text"] if has_dna else None
            fingerprint = dna_data["dna"]["fingerprint"] if has_dna else None
            is_anime = dna_data["dna"]["is_anime"] if has_dna else None
            production_info = dna_data["dna"]["production_info"] if has_dna else None
            content_advisories = dna_data["dna"].get("content_advisories", []) if has_dna else None
            social_suitability = dna_data["dna"]["social_suitability"] if has_dna else None
            viewing_context = dna_data["dna"]["viewing_context"] if has_dna else None

            # Create Media document
            media = MediaClass(
                tmdb_id=tmdb_id,

                # DNA
                is_anime=is_anime,
                production_method=production_info["method"] if production_info else None,
                animation_style=production_info["animation_style"] if production_info else None,

                essence_text=essence_text,
                essence_tags=essence_tags,
                fingerprint_scores=fingerprint["scores"] if fingerprint else None,
                fingerprint_highlight_keys=fingerprint["highlight_keys"] if fingerprint else None,
                content_advisories=content_advisories,

                suitability_solo_watch=social_suitability["solo_watch"] if social_suitability else None,
                suitability_date_night=social_suitability["date_night"] if social_suitability else None,
                suitability_group_party=social_suitability["group_party"] if social_suitability else None,
                suitability_family=social_suitability["family"] if social_suitability else None,
                suitability_partner=social_suitability["partner"] if social_suitability else None,
                suitability_friends=social_suitability["friends"] if social_suitability else None,
                suitability_kids=social_suitability["kids"] if social_suitability else None,
                suitability_teens=social_suitability["teens"] if social_suitability else None,
                suitability_adults=social_suitability["adults"] if social_suitability else None,
                suitability_intergenerational=social_suitability["intergenerational"] if social_suitability else None,
                suitability_public_viewing_safe=social_suitability["public_viewing_safe"] if social_suitability else None,

                context_is_thought_provoking=viewing_context["is_thought_provoking"] if viewing_context else None,
                context_is_pure_escapism=viewing_context["is_pure_escapism"] if viewing_context else None,
                context_is_background_friendly=viewing_context["is_background_friendly"] if viewing_context else None,
                context_is_comfort_watch=viewing_context["is_comfort_watch"] if viewing_context else None,
                context_is_binge_friendly=viewing_context["is_binge_friendly"] if viewing_context else None,
                context_is_drop_in_friendly=viewing_context["is_drop_in_friendly"] if viewing_context else None,
            
                # Metadata timestamps
                dna_created_at=to_timestamp(dna_data["created_at"]),
                dna_updated_at=to_timestamp(dna_data["updated_at"]),
            )

            media_documents.append(media)

        upsert_result = upsert_in_batches(
            connector=connector,
            table=media_table_name,
            records=media_documents,
        )
        
        media_type_key = 'movies' if is_movie else 'shows'
        entity_counts[media_type_key]["records_received"] += upsert_result["records_received"]
        entity_counts[media_type_key]["rows_upserted"] += upsert_result["rows_upserted"]
        
        # Insert all row for batch and track counts
        for table_name, batch in entity_batches.items():
            entity_upsert_result = upsert_in_batches(
                connector=connector,
                table=table_name,
                records=batch, 
            )
            entity_counts[table_name]["records_received"] += entity_upsert_result["records_received"]
            entity_counts[table_name]["rows_upserted"] += entity_upsert_result["rows_upserted"]

        start += BATCH_SIZE

    entity_counts["selected"] = selected
    entity_counts["skipped_without_details"] = skipped_without_details
    entity_counts["skipped_flagged"] = skipped_flagged
    return entity_counts


# An analysis reaches Crate through the recent copy above, which reads each change about
# once: the changes since the last successful run. An analysis it left out (a title without
# details or flagged as deleted at that moment), or that changed while the copy didn't run
# (analyses from before the copy existed, outages), never got there. The catch-up finds
# and copies them, so the recent copy carries no ids to its next run.
PUBLISHABLE_DNA = {"dna": {"$ne": None}, "vector_fingerprint": {"$ne": None}, "updated_at": {"$ne": None}}


def dna_missing_from_crate(connector: CrateConnector, mongo_dna, table: str) -> list[int]:
    """tmdb ids whose Crate row lacks the analysis Mongo has, or holds an older one.

    Only titles with a Crate row count: a title without one gets its analysis from the
    first catch-up after the details copy creates the row.
    """
    missing = []

    def check(batch: list[dict]) -> None:
        rows = connector.select(
            f"SELECT tmdb_id, dna_updated_at FROM {table} WHERE tmdb_id = ANY(?)",
            ([doc["tmdb_id"] for doc in batch],),
        )
        stored = {row["tmdb_id"]: row["dna_updated_at"] for row in rows}
        for doc in batch:
            if doc["tmdb_id"] not in stored:
                continue
            copied = stored[doc["tmdb_id"]]
            # Crate keeps milliseconds; allow a second of rounding.
            if copied is None or copied < to_timestamp(doc["updated_at"]) * 1000 - 1000:
                missing.append(doc["tmdb_id"])

    batch = []
    for doc in mongo_dna.find(PUBLISHABLE_DNA, {"_id": 0, "tmdb_id": 1, "updated_at": 1}).sort("tmdb_id", 1):
        batch.append(doc)
        if len(batch) == BATCH_SIZE:
            check(batch)
            batch = []
    if batch:
        check(batch)
    return missing


def catch_up(connector: CrateConnector, media_type: str) -> dict:
    """Copy every analysis that is missing from Crate or older there, whatever its age."""
    mongo_db = get_db()
    is_movie = media_type == "movie"
    tmdb_ids = dna_missing_from_crate(
        connector, mongo_db.dna_movie if is_movie else mongo_db.dna_tv, "movie" if is_movie else "show",
    )
    print(f"{media_type} analyses missing from Crate: {len(tmdb_ids)}")
    result = {"missing": len(tmdb_ids)}
    if tmdb_ids:
        result |= copy_media(
            connector=connector,
            query_selector=PUBLISHABLE_DNA | {"tmdb_id": {"$in": tmdb_ids}},
            media_type=media_type,
            recent_only=False,
        )
    return result


def main(movie_ids: list[str] = [], show_ids: list[str] = [], skip_movies = False):
    """Copy the analyses changed since the last successful run, per media type, then catch up."""
    init_mongodb()
    connector = CrateConnector()

    results = {}
    try:
        for key, media_type, ids in (("movies", "movie", movie_ids), ("shows", "show", show_ids)):
            if media_type == "movie" and skip_movies:
                results[key] = None
                continue
            if ids:
                query_selector = build_query_selector_for_object_ids(ids=ids)
            else:
                print(f"\nProcessing all {key}...", flush=True)
                query_selector = {}

            # A media type restricted to ids doesn't cover every change, so it keeps the
            # fixed window and leaves the sync state alone.
            selection = None if ids else sync_state.begin(get_db(), SYNC_JOB, media_type)
            results[key] = copy_media(
                connector=connector,
                query_selector=query_selector,
                media_type=media_type,
                since=selection.since if selection else None,
            )
            if selection:
                # Reached only when the media type's recent copy succeeded: a failure raises
                # above, and the next run reads the same changes again. The catch-up below
                # keeps no state, so its failure doesn't hold this time back.
                sync_state.commit(get_db(), selection, {
                    **{count: results[key][count]
                       for count in ("selected", "skipped_without_details", "skipped_flagged")},
                    **results[key].get(key, {"records_received": 0, "rows_upserted": 0}),
                })
                results[key]["selection"] = selection.report()

        # A run for explicit ids leaves the rest alone.
        if not movie_ids and not show_ids:
            results["catch_up"] = {
                "movies": None if skip_movies else catch_up(connector, "movie"),
                "shows": catch_up(connector, "show"),
            }
    finally:
        connector.disconnect()
        close_mongodb()

    return results


if __name__ == "__main__":
    main()