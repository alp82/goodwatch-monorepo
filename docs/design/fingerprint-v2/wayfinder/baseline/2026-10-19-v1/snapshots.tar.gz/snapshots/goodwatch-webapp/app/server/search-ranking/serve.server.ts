// Serving the search ranking: loading it at server start, the checks before a search is ranked, and the deadline.
// When a search can't be ranked (see servingFallback, or a ranking that fails or misses its deadline), the basic
// search serves it, and combinedSearch records the reason on the search_history row (ranker_fallback).
import { runsSearch } from "../role.server.ts"
import { RankingProgress } from "./ranking-progress.server.ts"
import type {
	Eligibility,
	ReadingFields,
} from "../combined-search/reading-retrieval.server.ts"
import { searchAdmission } from "../search-runtime/admission.server.ts"
import { queryEncoderState, startQueryEncoder } from "./query-encoder.server.ts"
import {
	type RankedSearch,
	type SearchRequest,
	rankSearch,
} from "./rank-search.server.ts"
import {
	loadedSearchIndexBuild,
	startSearchIndex,
} from "./search-index.server.ts"

// The ranking stage's deadline. The ranker's p95 on the webapp host was 469 ms one at a time and 585 ms two at a
// time, so this leaves room for load spikes while the fallback still answers within a few seconds.
// SEARCH_RANKING_DEADLINE_MS overrides it.
const SERVE_DEADLINE_MS = 1500

let started = false

/** At server start: loads the index and, when readings are possible, the query models in the background. */
export function startSearchRanking(
	options: { queryModels?: boolean } = {},
): void {
	if (!runsSearch()) return
	if (started) return
	started = true
	startSearchIndex()
	if (options.queryModels === false) {
		console.info(
			"Search ranking: query models not loaded, because SEARCH_STORAGE_KEY is not set and no search can have a reading",
		)
		return
	}
	startQueryEncoder().then(
		(startup) =>
			console.info(
				`Search ranking: query models ready in ${Math.round(startup.totalMs)} ms, ${startup.threads} encoder threads`,
			),
		() => {
			// Logged by the encoder; it retries on a later search.
		},
	)
}

export function servingDeadlineMs(): number {
	const ms = Number(process.env.SEARCH_RANKING_DEADLINE_MS)
	return Number.isFinite(ms) && ms > 0 ? ms : SERVE_DEADLINE_MS
}

export type ServingFallback =
	| "basic search"
	| "index not loaded"
	| "encoder not ready"
	| "encoder queue full"
	| "timeout"
	| "error"

/** Why the basic search must serve this search before the ranking is tried, or null when the ranking can. */
export function servingFallback(search: {
	hasReading: boolean
}): ServingFallback | null {
	if (!search.hasReading) return "basic search"
	if (!loadedSearchIndexBuild()) return "index not loaded"
	const encoder = queryEncoderState()
	if (!encoder.ready) return "encoder not ready"
	if (encoder.pending >= encoder.maxPending) return "encoder queue full"
	return null
}

export class RankingDeadlineError extends Error {
	readonly timings: Readonly<Record<string, number>>
	/** The ranking that missed the deadline: the one promise that holds the place in line, still running. */
	readonly ranking?: Promise<RankedSearch>

	constructor(
		ms: number,
		timings: Readonly<Record<string, number>> = Object.freeze({}),
		ranking?: Promise<RankedSearch>,
	) {
		super(`Search ranking missed its ${ms} ms deadline`)
		this.name = "RankingDeadlineError"
		this.timings = timings
		this.ranking = ranking
	}
}

/**
 * rankSearch with a deadline. On a miss it rejects with RankingDeadlineError; the ranking itself can't be cancelled,
 * so it finishes in the background and still counts as in flight. The error carries that same ranking: a caller that
 * already showed results may wait for it, and nothing is ranked a second time.
 */
export function rankForServing(
	reading: ReadingFields,
	request: SearchRequest,
	eligibility: Eligibility,
	deadlineMs = servingDeadlineMs(),
): Promise<RankedSearch> {
	const progress = request.progress ?? new RankingProgress()
	const ranking = rankSearch(reading, { ...request, progress }, eligibility)
	let timer: NodeJS.Timeout | undefined
	let missed = false
	const deadline = new Promise<never>((_, reject) => {
		timer = setTimeout(() => {
			missed = true
			searchAdmission.hold(ranking)
			reject(new RankingDeadlineError(deadlineMs, progress.snapshot(), ranking))
		}, deadlineMs)
	})
	// After a miss a caller may or may not wait for the ranking, so its failure is always logged here.
	ranking.catch(() => {
		if (missed)
			console.error("Search ranking failed after its deadline", {
				reason: "ranking",
			})
	})
	return Promise.race([ranking, deadline]).finally(() => clearTimeout(timer))
}
